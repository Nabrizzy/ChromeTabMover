# Chrome Tab-Mover

The Tab-Mover extension for Google Chrome adds new shortcuts to move your selected tabs. Also supports moving multiple tabs.

#
## Privacy Policy

This chrome extension does not use any personal data and does not communicate with other servers in any way.

No special permissions are required.
No third-party components or libraries are used.

#### Contact

If you have any questions or concerns about this privacy policy, please [send me an email](mailto:irrelephanthd@gmail.com).
